# =============================================================================
#  IE322 – Personal Stock Portfolio Simulation System
#  GUI Version | Tkinter + Matplotlib
#  Department of Industrial Engineering, KAU, Jeddah
#
#  BONUS FEATURES INCLUDED:
#    +2  Novel Trading Strategy (BBW + %B)
#    +2  Interactive GUI with real-time charts
#    +2  Monte Carlo Simulation with confidence intervals
#    +2  Optimization Algorithm — Brute Force + Genetic Algorithm
#    +2  Multiple Strategy Comparison
# =============================================================================

# ── Imports ───────────────────────────────────────────────────────────────────
import tkinter as tk
from tkinter import ttk, messagebox
import threading
import random
import time

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import matplotlib.gridspec as gridspec

import yfinance as yf
import warnings
warnings.filterwarnings("ignore")


# =============================================================================
#  SECTION 1 — DATA LAYER
# =============================================================================

class StockDataLoader:
    """
    Encapsulates all data-fetching operations from the Yahoo Finance API.
    """

    def __init__(self, ticker: str, start: str, end: str):
        self.ticker = ticker
        self.start  = start
        self.end    = end

    def fetch(self) -> pd.DataFrame:
        """Downloads historical closing prices and returns a clean DataFrame."""
        raw = yf.download(self.ticker, start=self.start,
                          end=self.end, progress=False)
        if raw.empty:
            raise ValueError(
                f"No data found for '{self.ticker}'. "
                "Check the ticker symbol or date range."
            )
        df = raw[["Close"]].copy()
        df.dropna(inplace=True)
        return df


# =============================================================================
#  SECTION 2 — STRATEGY LAYER
# =============================================================================

class BollingerStrategy:
    """
    Primary strategy — Bollinger Bands Width (BBW) + Bollinger Bands %B.

    Indicators:
        BBW  = (Upper - Lower) / SMA × 100   → volatility regime
        %B   = (Close - Lower) / (Upper - Lower) → normalized position
    """

    def __init__(self, window: int = 20, num_std: int = 2,
                 buy_threshold: float = 0.05, sell_threshold: float = 0.95):
        self.window         = window
        self.num_std        = num_std
        self.buy_threshold  = buy_threshold
        self.sell_threshold = sell_threshold

    def apply_indicators(self, data: pd.DataFrame) -> pd.DataFrame:
        df    = data.copy()
        close = df["Close"].squeeze()
        df["SMA"]        = close.rolling(window=self.window).mean()
        df["STD"]        = close.rolling(window=self.window).std()
        df["Upper_Band"] = df["SMA"] + self.num_std * df["STD"]
        df["Lower_Band"] = df["SMA"] - self.num_std * df["STD"]
        df["BBW"]        = ((df["Upper_Band"] - df["Lower_Band"]) / df["SMA"]) * 100
        band_range       = df["Upper_Band"] - df["Lower_Band"]
        df["Pct_B"]      = (close - df["Lower_Band"]) / band_range
        return df.dropna()

    def generate_signals(self, df: pd.DataFrame) -> pd.DataFrame:
        df            = df.copy()
        df["Signal"]  = 0
        pct_b         = df["Pct_B"]
        mean_bbw      = df["BBW"].mean()  # volatility threshold: only trade when market is active

        # Dual-indicator rule: BOTH conditions must be true to generate a signal.
        #
        #   Indicator 1 — BBW (volatility filter):
        #     Only trade when BBW > mean BBW → market is active enough for signal to be meaningful
        #     Suppresses false signals during low-volatility squeeze periods.
        #
        #   Indicator 2 — %B (entry timing):
        #     BUY  when %B < buy_threshold  → price is in the oversold zone
        #     SELL when %B > sell_threshold → price is in the overbought zone

        buy_condition  = (pct_b < self.buy_threshold)  & (df["BBW"] > mean_bbw)
        sell_condition = (pct_b > self.sell_threshold) & (df["BBW"] > mean_bbw)

        df.loc[buy_condition,  "Signal"] =  1
        df.loc[sell_condition, "Signal"] = -1
        return df


class SMACrossoverStrategy:
    """
    Comparison strategy — Classic SMA Crossover (Golden Cross / Death Cross).

    Rules:
        BUY  → short SMA crosses ABOVE long SMA  (Golden Cross)
        SELL → short SMA crosses BELOW long SMA  (Death Cross)
    """

    def __init__(self, short_window: int = 20, long_window: int = 50):
        self.short_window = short_window
        self.long_window  = long_window

    def apply_indicators(self, data: pd.DataFrame) -> pd.DataFrame:
        df    = data.copy()
        close = df["Close"].squeeze()
        df["SMA_Short"] = close.rolling(window=self.short_window).mean()
        df["SMA_Long"]  = close.rolling(window=self.long_window).mean()
        return df.dropna()

    def generate_signals(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        df["Signal"] = 0
        # Crossover detection
        prev_diff = (df["SMA_Short"] - df["SMA_Long"]).shift(1)
        curr_diff =  df["SMA_Short"] - df["SMA_Long"]
        df.loc[(prev_diff <= 0) & (curr_diff > 0), "Signal"] =  1   # Golden Cross
        df.loc[(prev_diff >= 0) & (curr_diff < 0), "Signal"] = -1   # Death Cross
        return df


# =============================================================================
#  SECTION 3 — PORTFOLIO LAYER
# =============================================================================

class PortfolioManager:
    """
    Simulates a virtual brokerage account.
    Encapsulated state: cash, shares, logs, value_history.
    """

    def __init__(self, initial_cash: float):
        self.initial_cash  = initial_cash
        self.cash          = initial_cash
        self.shares        = 0
        self.logs          = []
        self.value_history = []

    @staticmethod
    def _scalar(val):
        return float(val.iloc[0]) if isinstance(val, pd.Series) else float(val)

    def execute(self, df: pd.DataFrame) -> pd.DataFrame:
        df = df.copy()
        for date, row in df.iterrows():
            price  = self._scalar(row["Close"])
            signal = int(self._scalar(row["Signal"]))
            if signal == 1 and self.cash >= price:
                qty          = int(self.cash // price)
                self.shares += qty
                self.cash   -= qty * price
                self.logs.append({
                    "Date": date.date(), "Action": "BUY",
                    "Price": round(price, 2), "Shares": qty,
                    "Cash": round(self.cash, 2)
                })
            elif signal == -1 and self.shares > 0:
                self.cash  += self.shares * price
                self.logs.append({
                    "Date": date.date(), "Action": "SELL",
                    "Price": round(price, 2), "Shares": self.shares,
                    "Cash": round(self.cash, 2)
                })
                self.shares = 0
            self.value_history.append(self.cash + self.shares * price)
        df["Portfolio_Value"] = self.value_history
        return df

    def summary(self) -> dict:
        final  = self.value_history[-1] if self.value_history else self.initial_cash
        ret    = (final - self.initial_cash) / self.initial_cash * 100
        return {
            "Initial Capital":  self.initial_cash,
            "Final Value":      round(final, 2),
            "Total Return (%)": round(ret, 2),
            "Total Trades":     len(self.logs),
            "Shares Held":      self.shares,
            "Cash on Hand":     round(self.cash, 2),
        }


# =============================================================================
#  SECTION 4 — PERFORMANCE LAYER
# =============================================================================

class PerformanceAnalyzer:
    """Builds a Buy & Hold benchmark and computes a comparative scorecard."""

    def __init__(self, final_df: pd.DataFrame, initial_capital: float):
        self.df      = final_df.copy()
        self.capital = initial_capital
        self._build_benchmark()

    def _build_benchmark(self):
        first_price       = float(self.df["Close"].squeeze().iloc[0])
        shares            = int(self.capital // first_price)
        remainder         = self.capital - shares * first_price
        self.df["BnH"]    = remainder + shares * self.df["Close"].squeeze()

    def scorecard(self) -> pd.DataFrame:
        def metrics(col):
            vals    = self.df[col].values
            ret     = (vals[-1] - self.capital) / self.capital * 100
            dr      = pd.Series(vals).pct_change().dropna()
            vol     = dr.std() * np.sqrt(252) * 100
            sharpe  = (dr.mean() / dr.std()) * np.sqrt(252) if dr.std() else 0
            mdd     = ((pd.Series(vals) / pd.Series(vals).cummax()) - 1).min() * 100
            return {
                "Total Return (%)":    round(ret,    2),
                "Ann. Volatility (%)": round(vol,    2),
                "Sharpe Ratio":        round(sharpe, 3),
                "Max Drawdown (%)":    round(mdd,    2),
                "Final Value ($)":     round(vals[-1], 2),
            }
        return pd.DataFrame({
            "SMA+BBW+%B Strategy": metrics("Portfolio_Value"),
            "Buy & Hold":      metrics("BnH"),
        }).T


# =============================================================================
#  SECTION 5 — BONUS LAYER 1: BRUTE-FORCE OPTIMIZER
# =============================================================================

class BruteForceOptimizer:
    """
    Exhaustive search across SMA window values to find the most profitable.

    Algorithm:
        For each candidate window in [10, 15, 20, 25, 30, 40, 50]:
            simulate full strategy → record total return
        Return the window with highest return.

    This is a Grid Search optimization — simple, deterministic, and guaranteed
    to find the global optimum within the search space (but expensive for large
    parameter spaces).
    """

    def __init__(self, df_raw: pd.DataFrame, capital: float):
        self.df_raw  = df_raw
        self.capital = capital

    def optimize(self, windows=(10, 15, 20, 25, 30, 40, 50)) -> pd.DataFrame:
        results = []
        for w in windows:
            try:
                strat   = BollingerStrategy(window=int(w))
                df_ind  = strat.apply_indicators(self.df_raw.copy())
                df_sig  = strat.generate_signals(df_ind)
                mgr     = PortfolioManager(self.capital)
                mgr.execute(df_sig)
                summary = mgr.summary()
                results.append({
                    "Window":     int(w),
                    "Return (%)": summary["Total Return (%)"],
                    "Trades":     summary["Total Trades"],
                    "Final ($)":  summary["Final Value"],
                })
            except Exception:
                results.append({"Window": int(w), "Return (%)": -999,
                                "Trades": 0, "Final ($)": self.capital})
        return pd.DataFrame(results).sort_values("Return (%)", ascending=False)


# =============================================================================
#  SECTION 6 — BONUS LAYER 2: GENETIC ALGORITHM
# =============================================================================

class GeneticOptimizer:
    """
    Genetic Algorithm for optimizing Bollinger Strategy parameters.

    Chromosome (genome) = [window, buy_threshold, sell_threshold]
        window           ∈ [5, 60]
        buy_threshold    ∈ [0.00, 0.20]
        sell_threshold   ∈ [0.80, 1.00]

    Fitness = portfolio total return (%)

    Operators:
        Selection : Tournament (size 3)
        Crossover : Single-point average crossover
        Mutation  : Gaussian perturbation with rate 0.2

    GA Loop:
        Generation 0 → random population
        For each generation:
            evaluate fitness
            select parents (tournament)
            crossover → offspring
            mutate offspring
            replace population
        Return best individual found.
    """

    def __init__(self, df_raw: pd.DataFrame, capital: float,
                 population_size: int = 12, generations: int = 8,
                 mutation_rate: float = 0.2, tournament_k: int = 3,
                 seed: int = 42):
        self.df_raw          = df_raw
        self.capital         = capital
        self.pop_size        = population_size
        self.generations     = generations
        self.mutation_rate   = mutation_rate
        self.tournament_k    = tournament_k
        self.history         = []   # best fitness per generation
        random.seed(seed)
        np.random.seed(seed)

    # ── Helpers ───────────────────────────────────────────────────────────────
    def _random_chromosome(self):
        return {
            "window":   random.randint(5, 60),
            "buy_thr":  round(random.uniform(0.00, 0.20), 3),
            "sell_thr": round(random.uniform(0.80, 1.00), 3),
        }

    def _fitness(self, chrom):
        try:
            strat   = BollingerStrategy(
                window=int(chrom["window"]),
                buy_threshold=chrom["buy_thr"],
                sell_threshold=chrom["sell_thr"]
            )
            df_ind  = strat.apply_indicators(self.df_raw.copy())
            df_sig  = strat.generate_signals(df_ind)
            mgr     = PortfolioManager(self.capital)
            mgr.execute(df_sig)
            return mgr.summary()["Total Return (%)"]
        except Exception:
            return -999.0

    def _tournament_select(self, population, fitnesses):
        contenders = random.sample(range(len(population)), self.tournament_k)
        best       = max(contenders, key=lambda i: fitnesses[i])
        return population[best]

    def _crossover(self, p1, p2):
        return {
            "window":   int((p1["window"] + p2["window"]) / 2),
            "buy_thr":  round((p1["buy_thr"]  + p2["buy_thr"])  / 2, 3),
            "sell_thr": round((p1["sell_thr"] + p2["sell_thr"]) / 2, 3),
        }

    def _mutate(self, chrom):
        if random.random() < self.mutation_rate:
            chrom["window"] = max(5, min(60, chrom["window"] + random.randint(-5, 5)))
        if random.random() < self.mutation_rate:
            chrom["buy_thr"] = round(
                max(0.0, min(0.20, chrom["buy_thr"] + random.uniform(-0.03, 0.03))), 3)
        if random.random() < self.mutation_rate:
            chrom["sell_thr"] = round(
                max(0.80, min(1.0, chrom["sell_thr"] + random.uniform(-0.03, 0.03))), 3)
        return chrom

    # ── Main loop ─────────────────────────────────────────────────────────────
    def run(self, log_callback=None):
        # Generation 0
        population  = [self._random_chromosome() for _ in range(self.pop_size)]
        best_overall = None
        best_fit     = -1e9

        for gen in range(self.generations):
            fitnesses = [self._fitness(c) for c in population]

            # Track best
            gen_best_idx = max(range(len(population)), key=lambda i: fitnesses[i])
            if fitnesses[gen_best_idx] > best_fit:
                best_fit     = fitnesses[gen_best_idx]
                best_overall = dict(population[gen_best_idx])
            self.history.append({
                "Generation": gen + 1,
                "Best (%)":   round(best_fit, 2),
                "Avg (%)":    round(float(np.mean(fitnesses)), 2),
            })
            if log_callback:
                log_callback(gen + 1, best_fit, np.mean(fitnesses))

            # Build next generation
            next_pop = []
            # Elitism: keep best individual
            next_pop.append(dict(best_overall))
            while len(next_pop) < self.pop_size:
                p1 = self._tournament_select(population, fitnesses)
                p2 = self._tournament_select(population, fitnesses)
                child = self._crossover(p1, p2)
                child = self._mutate(child)
                next_pop.append(child)
            population = next_pop

        return best_overall, best_fit, pd.DataFrame(self.history)


# =============================================================================
#  SECTION 6.5 — BONUS LAYER 3: MONTE CARLO SIMULATION
# =============================================================================

class MonteCarloSimulator:
    """
    Projects future price paths using Geometric Brownian Motion (GBM).

    Model:
        S(t+1) = S(t) * exp((μ - σ²/2)·dt + σ·√dt·ε),  ε ~ N(0,1)

    μ and σ are estimated from the historical log-return series.

    Output: N simulated price paths → percentile envelopes (5 / 50 / 95)
    """

    def __init__(self, df_raw: pd.DataFrame,
                 n_simulations: int = 300,
                 n_days: int = 252,
                 seed: int = 42):
        self.df_raw  = df_raw
        self.n_sims  = n_simulations
        self.n_days  = n_days
        np.random.seed(seed)

    def run(self) -> dict:
        close       = self.df_raw["Close"].squeeze()
        log_ret     = np.log(close / close.shift(1)).dropna()
        mu          = float(log_ret.mean())
        sigma       = float(log_ret.std())
        S0          = float(close.iloc[-1])

        paths    = np.zeros((self.n_days, self.n_sims))
        paths[0] = S0
        for t in range(1, self.n_days):
            eps       = np.random.standard_normal(self.n_sims)
            paths[t]  = paths[t - 1] * np.exp(
                (mu - 0.5 * sigma ** 2) + sigma * eps
            )

        final    = paths[-1]
        return {
            "paths":       paths,
            "p5":          np.percentile(paths, 5,  axis=1),
            "p50":         np.percentile(paths, 50, axis=1),
            "p95":         np.percentile(paths, 95, axis=1),
            "S0":          S0,
            "mu_daily":    mu,
            "sigma_daily": sigma,
            "prob_profit": float(np.mean(final > S0) * 100),
            "expected":    float(np.mean(final)),
            "ci_low":      float(np.percentile(final, 5)),
            "ci_high":     float(np.percentile(final, 95)),
        }


# =============================================================================
#  SECTION 7 — GUI LAYER
# =============================================================================

# ── Color Palette ─────────────────────────────────────────────────────────────
BG_DARK    = "#0D1117"
BG_PANEL   = "#161B22"
BG_INPUT   = "#21262D"
ACCENT     = "#58A6FF"
ACCENT2    = "#3FB950"
RED        = "#F85149"
ORANGE     = "#F0883E"
GOLD       = "#E3B341"
PURPLE     = "#A371F7"
TEXT_MAIN  = "#E6EDF3"
TEXT_SUB   = "#8B949E"
BORDER     = "#30363D"
CHART_BG   = "#0D1117"


class StockPortfolioApp(tk.Tk):
    """Main application window — IE322 Stock Portfolio Simulation System."""

    def __init__(self):
        super().__init__()
        self.title("IE322 — Stock Portfolio Simulation System")
        self.configure(bg=BG_DARK)
        self.state("zoomed")
        self.resizable(True, True)

        # Cached data
        self._df_raw     = None
        self._df_signals = None
        self._final_df   = None
        self._mgr        = None
        self._analyzer   = None

        self._build_layout()
        self._build_left_panel()
        self._build_chart_area()
        self._build_bottom_area()

    # ── Layout skeleton ───────────────────────────────────────────────────────
    def _build_layout(self):
        self.left_frame  = tk.Frame(self, bg=BG_PANEL, width=240)
        self.right_frame = tk.Frame(self, bg=BG_DARK)
        self.left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(8, 0), pady=8)
        self.left_frame.pack_propagate(False)
        self.right_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True,
                              padx=8, pady=8)
        self.chart_frame  = tk.Frame(self.right_frame, bg=BG_DARK)
        self.bottom_frame = tk.Frame(self.right_frame, bg=BG_DARK)
        self.chart_frame.pack(fill=tk.BOTH, expand=True)
        self.bottom_frame.pack(fill=tk.BOTH, expand=True, pady=(6, 0))

    # ── Left Settings Panel ───────────────────────────────────────────────────
    def _build_left_panel(self):
        pad = {"padx": 12, "pady": 4}

        tk.Label(self.left_frame, text="⚙  Settings",
                 bg=BG_PANEL, fg=ACCENT,
                 font=("Consolas", 13, "bold")).pack(pady=(16, 8))
        tk.Frame(self.left_frame, bg=BORDER, height=1).pack(
            fill=tk.X, padx=10, pady=4)

        def label(text):
            tk.Label(self.left_frame, text=text,
                     bg=BG_PANEL, fg=TEXT_SUB,
                     font=("Consolas", 9)).pack(anchor="w", **pad)

        def entry(default):
            e = tk.Entry(self.left_frame, bg=BG_INPUT, fg=TEXT_MAIN,
                         insertbackground=TEXT_MAIN,
                         font=("Consolas", 10), relief="flat", bd=4)
            e.insert(0, default)
            e.pack(fill=tk.X, padx=12, pady=(0, 4))
            return e

        def combo(values, default):
            c = ttk.Combobox(self.left_frame, values=values,
                             font=("Consolas", 10), state="readonly")
            c.set(default)
            c.pack(fill=tk.X, padx=12, pady=(0, 4))
            return c

        label("Ticker Symbol")
        self.ticker_var = combo(
            ["AAPL", "MSFT", "TSLA", "GOOGL", "2222.SR", "1120.SR"],
            "AAPL"
        )
        label("Start Date  (YYYY-MM-DD)")
        self.start_entry = entry("2022-01-01")
        label("End Date  (YYYY-MM-DD)")
        self.end_entry = entry("2024-01-01")
        label("Initial Capital ($)")
        self.capital_entry = entry("100000")

        tk.Frame(self.left_frame, bg=BORDER, height=1).pack(
            fill=tk.X, padx=10, pady=8)
        label("SMA Window (days)")
        self.window_entry = entry("20")
        label("Buy Threshold  (%B,  0.00 – 0.20)")
        self.buy_thr_entry = entry("0.05")
        label("Sell Threshold  (%B,  0.80 – 1.00)")
        self.sell_thr_entry = entry("0.95")

        # Run button
        self.run_btn = tk.Button(
            self.left_frame, text="▶  Run Simulation",
            bg=ACCENT, fg=BG_DARK, font=("Consolas", 11, "bold"),
            relief="flat", cursor="hand2", activebackground="#79C0FF",
            command=self._run_thread
        )
        self.run_btn.pack(fill=tk.X, padx=12, pady=(14, 6))

        # Live Mode button — polls yfinance every 60 seconds for today's data
        self._live_running = False   # flag: is live mode active?
        self.live_btn = tk.Button(
            self.left_frame, text="🔴  Start Live Mode",
            bg=RED, fg=TEXT_MAIN, font=("Consolas", 10, "bold"),
            relief="flat", cursor="hand2", activebackground="#FF6B6B",
            command=self._toggle_live
        )
        self.live_btn.pack(fill=tk.X, padx=12, pady=(0, 6))

        # ── BONUS BUTTONS ─────────────────────────────────────────────────────
        tk.Frame(self.left_frame, bg=BORDER, height=1).pack(
            fill=tk.X, padx=10, pady=8)
        tk.Label(self.left_frame, text="🎁  Bonus Features",
                 bg=BG_PANEL, fg=GOLD,
                 font=("Consolas", 10, "bold")).pack(pady=(2, 6))

        # Bonus #1 — Brute Force Optimization
        self.opt_btn = tk.Button(
            self.left_frame, text="🔍  Optimize SMA (Brute Force)",
            bg=ORANGE, fg=BG_DARK, font=("Consolas", 9, "bold"),
            relief="flat", cursor="hand2", activebackground="#FFA657",
            command=self._optimize_thread
        )
        self.opt_btn.pack(fill=tk.X, padx=12, pady=3)

        # Bonus #2 — Genetic Algorithm
        self.ga_btn = tk.Button(
            self.left_frame, text="🧬  Genetic Algorithm",
            bg=PURPLE, fg=BG_DARK, font=("Consolas", 9, "bold"),
            relief="flat", cursor="hand2", activebackground="#BC8CFF",
            command=self._ga_thread
        )
        self.ga_btn.pack(fill=tk.X, padx=12, pady=3)

        # Bonus #3 — Multi-Strategy Comparison
        self.cmp_btn = tk.Button(
            self.left_frame, text="📊  Compare Strategies",
            bg=ACCENT2, fg=BG_DARK, font=("Consolas", 9, "bold"),
            relief="flat", cursor="hand2", activebackground="#56D364",
            command=self._compare_thread
        )
        self.cmp_btn.pack(fill=tk.X, padx=12, pady=3)

        # Bonus #4 — Monte Carlo Simulation
        self.mc_btn = tk.Button(
            self.left_frame, text="🎲  Monte Carlo",
            bg="#1F6FEB", fg=TEXT_MAIN, font=("Consolas", 9, "bold"),
            relief="flat", cursor="hand2", activebackground="#388BFD",
            command=self._mc_thread
        )
        self.mc_btn.pack(fill=tk.X, padx=12, pady=3)

        # Status
        self.status_var = tk.StringVar(value="Ready.")
        tk.Label(self.left_frame, textvariable=self.status_var,
                 bg=BG_PANEL, fg=TEXT_SUB, font=("Consolas", 8),
                 wraplength=200).pack(padx=12, pady=(10, 4))

        # Signal legend
        tk.Frame(self.left_frame, bg=BORDER, height=1).pack(
            fill=tk.X, padx=10, pady=8)
        for sym, col, txt in [("▲", ACCENT2, "BUY  signal"),
                              ("▼", RED,    "SELL signal"),
                              ("—", TEXT_SUB, "HOLD")]:
            row = tk.Frame(self.left_frame, bg=BG_PANEL)
            row.pack(anchor="w", padx=14, pady=1)
            tk.Label(row, text=sym, bg=BG_PANEL, fg=col,
                     font=("Consolas", 10, "bold")).pack(side=tk.LEFT)
            tk.Label(row, text=f"  {txt}", bg=BG_PANEL, fg=TEXT_SUB,
                     font=("Consolas", 9)).pack(side=tk.LEFT)

    # ── Top Chart Area ────────────────────────────────────────────────────────
    def _build_chart_area(self):
        self.fig_top = plt.Figure(figsize=(12, 5), facecolor=CHART_BG)
        gs = gridspec.GridSpec(1, 3, figure=self.fig_top, wspace=0.35,
                               left=0.05, right=0.97, top=0.88, bottom=0.18)
        self.ax_price = self.fig_top.add_subplot(gs[0, 0])
        self.ax_bbw   = self.fig_top.add_subplot(gs[0, 1])
        self.ax_pctb  = self.fig_top.add_subplot(gs[0, 2])
        for ax in [self.ax_price, self.ax_bbw, self.ax_pctb]:
            ax.set_facecolor(BG_PANEL)
            ax.tick_params(colors=TEXT_SUB, labelsize=7)
            for sp in ax.spines.values():
                sp.set_edgecolor(BORDER)
        canvas = FigureCanvasTkAgg(self.fig_top, master=self.chart_frame)
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        self.canvas_top = canvas

    # ── Bottom Area ───────────────────────────────────────────────────────────
    def _build_bottom_area(self):
        self.fig_bot = plt.Figure(figsize=(6, 3), facecolor=CHART_BG)
        self.ax_port = self.fig_bot.add_subplot(111)
        self.ax_port.set_facecolor(BG_PANEL)
        self.ax_port.tick_params(colors=TEXT_SUB, labelsize=7)
        for sp in self.ax_port.spines.values():
            sp.set_edgecolor(BORDER)

        port_frame = tk.Frame(self.bottom_frame, bg=BG_DARK)
        port_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        canvas2 = FigureCanvasTkAgg(self.fig_bot, master=port_frame)
        canvas2.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        self.canvas_bot = canvas2

        right_bot = tk.Frame(self.bottom_frame, bg=BG_DARK, width=420)
        right_bot.pack(side=tk.LEFT, fill=tk.BOTH, padx=(6, 0))
        right_bot.pack_propagate(False)

        tk.Label(right_bot, text="📋  Trade Log",
                 bg=BG_DARK, fg=ACCENT,
                 font=("Consolas", 10, "bold")).pack(anchor="w", pady=(2, 2))

        style = ttk.Style()
        style.theme_use("default")
        style.configure("Dark.Treeview",
                        background=BG_PANEL, foreground=TEXT_MAIN,
                        fieldbackground=BG_PANEL, rowheight=20,
                        font=("Consolas", 8))
        style.configure("Dark.Treeview.Heading",
                        background=BG_INPUT, foreground=ACCENT,
                        font=("Consolas", 8, "bold"))
        style.map("Dark.Treeview", background=[("selected", ACCENT)])

        cols = ("Date", "Action", "Price", "Shares", "Cash")
        self.trade_tree = ttk.Treeview(right_bot, columns=cols,
                                       show="headings", height=6,
                                       style="Dark.Treeview")
        for c in cols:
            self.trade_tree.heading(c, text=c)
            self.trade_tree.column(c, width=78, anchor="center")
        sb = ttk.Scrollbar(right_bot, orient="vertical",
                           command=self.trade_tree.yview)
        self.trade_tree.configure(yscrollcommand=sb.set)
        self.trade_tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        sb.pack(side=tk.LEFT, fill=tk.Y)

        # Scorecard
        score_frame = tk.Frame(self.bottom_frame, bg=BG_PANEL,
                               relief="flat", bd=0, width=280)
        score_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(6, 0))
        score_frame.pack_propagate(False)
        tk.Label(score_frame, text="📊  Scorecard",
                 bg=BG_PANEL, fg=ACCENT,
                 font=("Consolas", 10, "bold")).pack(anchor="w",
                                                     padx=10, pady=(6, 4))
        tk.Frame(score_frame, bg=BORDER, height=1).pack(
            fill=tk.X, padx=8, pady=2)
        self.score_labels = {}
        metrics = ["Total Return (%)", "Ann. Volatility (%)",
                   "Sharpe Ratio", "Max Drawdown (%)", "Final Value ($)"]
        for m in metrics:
            row = tk.Frame(score_frame, bg=BG_PANEL)
            row.pack(fill=tk.X, padx=10, pady=3)
            tk.Label(row, text=m, bg=BG_PANEL, fg=TEXT_SUB,
                     font=("Consolas", 8), width=20,
                     anchor="w").pack(side=tk.LEFT)
            strat_lbl = tk.Label(row, text="—", bg=BG_PANEL,
                                 fg=ACCENT2, font=("Consolas", 8, "bold"),
                                 width=8)
            strat_lbl.pack(side=tk.LEFT)
            bnh_lbl   = tk.Label(row, text="—", bg=BG_PANEL,
                                 fg=TEXT_SUB, font=("Consolas", 8), width=8)
            bnh_lbl.pack(side=tk.LEFT)
            self.score_labels[m] = (strat_lbl, bnh_lbl)
        tk.Frame(score_frame, bg=BORDER, height=1).pack(
            fill=tk.X, padx=8, pady=4)
        legend_row = tk.Frame(score_frame, bg=BG_PANEL)
        legend_row.pack(padx=10)
        tk.Label(legend_row, text="■ Strategy", bg=BG_PANEL,
                 fg=ACCENT2, font=("Consolas", 7)).pack(side=tk.LEFT,
                                                        padx=(0, 8))
        tk.Label(legend_row, text="■ Buy & Hold", bg=BG_PANEL,
                 fg=TEXT_SUB, font=("Consolas", 7)).pack(side=tk.LEFT)

    # =========================================================================
    #  CORE SIMULATION
    # =========================================================================
    def _run_thread(self):
        self.run_btn.config(state="disabled", text="⏳  Loading...")
        self.status_var.set("Fetching data...")
        threading.Thread(target=self._run_simulation, daemon=True).start()

    def _read_inputs(self):
        return {
            "ticker":   self.ticker_var.get().strip(),
            "start":    self.start_entry.get().strip(),
            "end":      self.end_entry.get().strip(),
            "capital":  float(self.capital_entry.get().strip()),
            "window":   int(self.window_entry.get().strip()),
            "buy_thr":  float(self.buy_thr_entry.get().strip()),
            "sell_thr": float(self.sell_thr_entry.get().strip()),
        }

    def _run_simulation(self):
        try:
            cfg = self._read_inputs()
            self.status_var.set("Fetching market data...")
            df_raw  = StockDataLoader(cfg["ticker"], cfg["start"], cfg["end"]).fetch()
            self.status_var.set("Computing indicators...")
            strat   = BollingerStrategy(window=cfg["window"],
                                        buy_threshold=cfg["buy_thr"],
                                        sell_threshold=cfg["sell_thr"])
            df_ind  = strat.apply_indicators(df_raw)
            df_sig  = strat.generate_signals(df_ind)
            self.status_var.set("Simulating portfolio...")
            mgr     = PortfolioManager(cfg["capital"])
            final_df = mgr.execute(df_sig)
            analyzer = PerformanceAnalyzer(final_df, cfg["capital"])

            # Cache
            self._df_raw     = df_raw
            self._df_signals = df_sig
            self._final_df   = final_df
            self._mgr        = mgr
            self._analyzer   = analyzer

            self.after(0, lambda: self._update_ui(cfg["ticker"]))
        except Exception as e:
            self.after(0, lambda: self._on_error(str(e)))

    def _on_error(self, msg):
        messagebox.showerror("Error", msg)
        self.run_btn.config(state="normal", text="▶  Run Simulation")
        self.status_var.set("Error. Check inputs.")

    # =========================================================================
    #  LIVE MODE — polls yfinance every 60 seconds for today's 1-minute data
    # =========================================================================

    def _toggle_live(self):
        if self._live_running:
            # Stop live mode
            self._live_running = False
            self.live_btn.config(text="🔴  Start Live Mode", bg=RED)
            self.status_var.set("Live mode stopped.")
        else:
            # Start live mode
            self._live_running = True
            self.live_btn.config(text="⏹  Stop Live Mode", bg="#6E4040")
            self.status_var.set("Live mode started — refreshing every 60s...")
            threading.Thread(target=self._live_loop, daemon=True).start()

    def _live_loop(self):
        """Background thread: fetches today's 1-minute data every 60 seconds."""
        ticker = self.ticker_var.get().strip()
        try:
            capital = float(self.capital_entry.get().strip())
            window  = int(self.window_entry.get().strip())
        except ValueError:
            self.after(0, lambda: self._on_error("Invalid capital or window value."))
            self._live_running = False
            return

        while self._live_running:
            try:
                # Fetch today's data at 1-minute resolution from yfinance
                df_raw = yf.download(ticker, period="1d", interval="1m", progress=False)

                if df_raw.empty:
                    self.after(0, lambda: self.status_var.set(
                        "Live: No data yet — market may be closed."))
                else:
                    df_raw = df_raw[["Close"]].copy()
                    df_raw.dropna(inplace=True)

                    # Need at least `window` candles to compute indicators
                    if len(df_raw) >= window:
                        strat    = BollingerStrategy(window=window)
                        df_ind   = strat.apply_indicators(df_raw)
                        df_sig   = strat.generate_signals(df_ind)
                        mgr      = PortfolioManager(capital)
                        final_df = mgr.execute(df_sig)
                        analyzer = PerformanceAnalyzer(final_df, capital)

                        # Cache so other buttons can still use the data
                        self._df_raw     = df_raw
                        self._df_signals = df_sig
                        self._final_df   = final_df
                        self._mgr        = mgr
                        self._analyzer   = analyzer

                        last_price = float(df_raw["Close"].squeeze().iloc[-1])
                        s          = mgr.summary()

                        # Schedule UI update on the main thread
                        self.after(0, lambda: self._update_ui(ticker))
                        self.after(0, lambda: self.status_var.set(
                            f"Live | {ticker} @ ${last_price:.2f} | "
                            f"Return: {s['Total Return (%)']:+.2f}% | "
                            f"Trades: {s['Total Trades']} | "
                            f"Refreshes every 60s"
                        ))
                    else:
                        self.after(0, lambda: self.status_var.set(
                            f"Live: Collecting data... ({len(df_raw)}/{window} candles)"))

            except Exception as e:
                err = str(e)
                self.after(0, lambda: self.status_var.set(f"Live error: {err}"))

            # Wait 60 seconds before next fetch (checks stop flag every second)
            for _ in range(60):
                if not self._live_running:
                    break
                time.sleep(1)

    def _update_ui(self, ticker):
        self._draw_top_charts(ticker, self._df_signals)
        self._draw_portfolio_chart(ticker, self._final_df, self._analyzer)
        self._populate_trade_log(self._mgr.logs)
        self._populate_scorecard(self._analyzer.scorecard())
        s = self._mgr.summary()
        self.status_var.set(
            f"Done. Return: {s['Total Return (%)']:+.2f}%  |  Trades: {s['Total Trades']}"
        )
        self.run_btn.config(state="normal", text="▶  Run Simulation")

    # =========================================================================
    #  BONUS #1 — BRUTE FORCE OPTIMIZER
    # =========================================================================
    def _optimize_thread(self):
        self.opt_btn.config(state="disabled", text="⏳  Optimizing...")
        self.status_var.set("Brute-force optimization running...")
        threading.Thread(target=self._run_optimize, daemon=True).start()

    def _run_optimize(self):
        try:
            cfg = self._read_inputs()
            df_raw = (self._df_raw
                      if self._df_raw is not None
                      else StockDataLoader(cfg["ticker"], cfg["start"], cfg["end"]).fetch())
            optimizer = BruteForceOptimizer(df_raw, cfg["capital"])
            results   = optimizer.optimize()
            self.after(0, lambda: self._show_optimize_result(results, cfg["ticker"]))
        except Exception as e:
            self.after(0, lambda: messagebox.showerror("Optimization Error", str(e)))
        finally:
            self.after(0, lambda: self.opt_btn.config(
                state="normal", text="🔍  Optimize SMA (Brute Force)"))
            self.after(0, lambda: self.status_var.set("Optimization complete."))

    def _show_optimize_result(self, results: pd.DataFrame, ticker: str):
        win = tk.Toplevel(self)
        win.title("SMA Brute-Force Optimization Results")
        win.configure(bg=BG_DARK)
        win.geometry("700x520")

        tk.Label(win, text=f"🏆  Optimal SMA Window for  {ticker}",
                 bg=BG_DARK, fg=GOLD,
                 font=("Consolas", 14, "bold")).pack(pady=(14, 4))
        best_row = results.iloc[0]
        tk.Label(win,
                 text=f"Winner: {int(best_row['Window'])} days   |   Return: {best_row['Return (%)']:+.2f}%",
                 bg=BG_DARK, fg=ACCENT2,
                 font=("Consolas", 11, "bold")).pack(pady=(0, 12))

        # Bar chart
        fig = plt.Figure(figsize=(7, 3), facecolor=BG_DARK)
        ax  = fig.add_subplot(111)
        ax.set_facecolor(BG_PANEL)
        sorted_r = results.sort_values("Window")
        colors   = [GOLD if w == best_row["Window"] else ACCENT
                    for w in sorted_r["Window"]]
        ax.bar(sorted_r["Window"].astype(str), sorted_r["Return (%)"],
               color=colors, edgecolor=BORDER)
        ax.set_xlabel("SMA Window (days)", color=TEXT_SUB, fontsize=9)
        ax.set_ylabel("Total Return (%)",  color=TEXT_SUB, fontsize=9)
        ax.set_title(f"Brute-Force Search Results — {ticker}",
                     color=TEXT_MAIN, fontweight="bold")
        ax.tick_params(colors=TEXT_SUB, labelsize=8)
        for sp in ax.spines.values():
            sp.set_edgecolor(BORDER)
        ax.axhline(0, color=TEXT_SUB, lw=0.6)
        ax.grid(alpha=0.15, color=BORDER)
        canvas = FigureCanvasTkAgg(fig, master=win)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True, padx=12, pady=4)

        # Results table
        cols = ("Window", "Return (%)", "Trades", "Final ($)")
        tree = ttk.Treeview(win, columns=cols, show="headings",
                             height=4, style="Dark.Treeview")
        for c in cols:
            tree.heading(c, text=c)
            tree.column(c, width=100, anchor="center")
        for _, r in results.iterrows():
            tree.insert("", "end", values=(
                int(r["Window"]),
                f"{r['Return (%)']:+.2f}",
                int(r["Trades"]),
                f"${r['Final ($)']:,.0f}"
            ))
        tree.pack(fill=tk.X, padx=12, pady=(4, 12))

    # =========================================================================
    #  BONUS #2 — GENETIC ALGORITHM
    # =========================================================================
    def _ga_thread(self):
        self.ga_btn.config(state="disabled", text="⏳  Evolving...")
        self.status_var.set("Genetic Algorithm running...")
        threading.Thread(target=self._run_ga, daemon=True).start()

    def _run_ga(self):
        try:
            cfg = self._read_inputs()
            df_raw = (self._df_raw
                      if self._df_raw is not None
                      else StockDataLoader(cfg["ticker"], cfg["start"], cfg["end"]).fetch())
            ga = GeneticOptimizer(df_raw, cfg["capital"],
                                   population_size=12, generations=8)
            best, best_fit, history = ga.run()
            # Auto-fill the threshold and window fields with the GA's best result
            self.after(0, lambda: self._apply_ga_result(best))
            self.after(0, lambda: self._show_ga_result(best, best_fit, history,
                                                        cfg["ticker"]))
        except Exception as e:
            self.after(0, lambda: messagebox.showerror("GA Error", str(e)))
        finally:
            self.after(0, lambda: self.ga_btn.config(
                state="normal", text="🧬  Genetic Algorithm"))
            self.after(0, lambda: self.status_var.set("GA complete."))

    def _apply_ga_result(self, best):
        """Fill the settings panel with the GA's best chromosome so the user can run it directly."""
        self.window_entry.delete(0, tk.END)
        self.window_entry.insert(0, str(best["window"]))
        self.buy_thr_entry.delete(0, tk.END)
        self.buy_thr_entry.insert(0, str(best["buy_thr"]))
        self.sell_thr_entry.delete(0, tk.END)
        self.sell_thr_entry.insert(0, str(best["sell_thr"]))
        self.status_var.set(
            f"GA done — settings updated: window={best['window']}, "
            f"buy={best['buy_thr']}, sell={best['sell_thr']}. "
            f"Click ▶ Run Simulation to apply."
        )

    def _show_ga_result(self, best, best_fit, history, ticker):
        win = tk.Toplevel(self)
        win.title("Genetic Algorithm — Optimization Results")
        win.configure(bg=BG_DARK)
        win.geometry("780x600")

        tk.Label(win, text=f"🧬  Genetic Algorithm Results — {ticker}",
                 bg=BG_DARK, fg=PURPLE,
                 font=("Consolas", 14, "bold")).pack(pady=(14, 4))
        tk.Label(win,
                 text=(f"Best Chromosome:  window={best['window']}  |  "
                       f"buy_thr={best['buy_thr']}  |  sell_thr={best['sell_thr']}"),
                 bg=BG_DARK, fg=TEXT_MAIN,
                 font=("Consolas", 10)).pack(pady=2)
        tk.Label(win, text=f"Best Fitness (Return):  {best_fit:+.2f}%",
                 bg=BG_DARK, fg=ACCENT2,
                 font=("Consolas", 11, "bold")).pack(pady=(0, 10))

        # Evolution chart
        fig = plt.Figure(figsize=(7.5, 3.5), facecolor=BG_DARK)
        ax  = fig.add_subplot(111)
        ax.set_facecolor(BG_PANEL)
        ax.plot(history["Generation"], history["Best (%)"],
                color=PURPLE, marker="o", lw=2, label="Best Fitness")
        ax.plot(history["Generation"], history["Avg (%)"],
                color=ACCENT, marker="s", lw=1.5, ls="--", label="Avg Fitness")
        ax.set_xlabel("Generation", color=TEXT_SUB, fontsize=9)
        ax.set_ylabel("Fitness — Return (%)", color=TEXT_SUB, fontsize=9)
        ax.set_title("Evolution of Population Fitness",
                     color=TEXT_MAIN, fontweight="bold")
        ax.tick_params(colors=TEXT_SUB, labelsize=8)
        ax.legend(facecolor=BG_PANEL, labelcolor=TEXT_MAIN, fontsize=8)
        for sp in ax.spines.values():
            sp.set_edgecolor(BORDER)
        ax.grid(alpha=0.15, color=BORDER)
        canvas = FigureCanvasTkAgg(fig, master=win)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True, padx=12, pady=4)

        # History table
        cols = ("Generation", "Best (%)", "Avg (%)")
        tree = ttk.Treeview(win, columns=cols, show="headings",
                            height=5, style="Dark.Treeview")
        for c in cols:
            tree.heading(c, text=c)
            tree.column(c, width=100, anchor="center")
        for _, r in history.iterrows():
            tree.insert("", "end", values=(
                int(r["Generation"]),
                f"{r['Best (%)']:+.2f}",
                f"{r['Avg (%)']:+.2f}",
            ))
        tree.pack(fill=tk.X, padx=12, pady=(4, 12))

    # =========================================================================
    #  BONUS #3 — FULL ABLATION COMPARISON (all indicator combinations)
    # =========================================================================
    def _compare_thread(self):
        self.cmp_btn.config(state="disabled", text="⏳  Comparing...")
        self.status_var.set("Running full ablation comparison...")
        threading.Thread(target=self._run_compare, daemon=True).start()

    @staticmethod
    def _build_bnh_curve(df_raw, capital):
        first_price = float(df_raw["Close"].squeeze().iloc[0])
        shares      = int(capital // first_price)
        remainder   = capital - shares * first_price
        return list(remainder + shares * df_raw["Close"].squeeze().values)

    @staticmethod
    def _simulate(df_signals, capital):
        """Run PortfolioManager on a signal DataFrame and return (manager, summary)."""
        mgr = PortfolioManager(capital)
        mgr.execute(df_signals)
        return mgr

    def _build_all_signals(self, df_raw, window):
        """Generate signal DataFrames for every indicator combination."""
        strat   = BollingerStrategy(window=window)
        df_ind  = strat.apply_indicators(df_raw.copy())
        close   = df_ind["Close"].squeeze()
        pct_b   = df_ind["Pct_B"]
        mean_bbw = df_ind["BBW"].mean()
        sma     = df_ind["SMA"]

        def make_df(buy_mask, sell_mask):
            df = df_ind.copy()
            df["Signal"] = 0
            df.loc[buy_mask,  "Signal"] =  1
            df.loc[sell_mask, "Signal"] = -1
            return df

        # SMA crossover masks (price crosses above/below SMA)
        prev_rel   = (close - sma).shift(1)
        curr_rel   =  close - sma
        sma_buy    = (prev_rel < 0) & (curr_rel >= 0)
        sma_sell   = (prev_rel >= 0) & (curr_rel < 0)

        signals = {
            "%B Only":        make_df(pct_b < 0.05,
                                      pct_b > 0.95),
            "SMA Only":       make_df(sma_buy,
                                      sma_sell),
            "BBW + %B":       make_df((pct_b < 0.05)  & (df_ind["BBW"] > mean_bbw),
                                      (pct_b > 0.95)  & (df_ind["BBW"] > mean_bbw)),
            "SMA + %B":       make_df((pct_b < 0.05)  & (close > sma),
                                      (pct_b > 0.95)  & (close < sma)),
            "SMA + BBW":      make_df(sma_buy          & (df_ind["BBW"] > mean_bbw),
                                      sma_sell         & (df_ind["BBW"] > mean_bbw)),
            "SMA + BBW + %B": make_df((pct_b < 0.05)  & (df_ind["BBW"] > mean_bbw) & (close > sma),
                                      (pct_b > 0.95)  & (df_ind["BBW"] > mean_bbw) & (close < sma)),
        }
        return signals

    def _run_compare(self):
        try:
            cfg    = self._read_inputs()
            df_raw = (self._df_raw
                      if self._df_raw is not None
                      else StockDataLoader(cfg["ticker"], cfg["start"], cfg["end"]).fetch())

            all_signals = self._build_all_signals(df_raw, cfg["window"])

            curves    = {}
            summaries = {}

            for name, df_sig in all_signals.items():
                mgr = self._simulate(df_sig, cfg["capital"])
                curves[name]    = mgr.value_history
                summaries[name] = mgr.summary()

            # Buy & Hold
            bnh = self._build_bnh_curve(df_raw, cfg["capital"])
            curves["Buy & Hold"] = bnh
            first_p = float(df_raw["Close"].squeeze().iloc[0])
            last_p  = float(df_raw["Close"].squeeze().iloc[-1])
            shares  = int(cfg["capital"] // first_p)
            rem     = cfg["capital"] - shares * first_p
            summaries["Buy & Hold"] = {
                "Total Return (%)": round((rem + shares * last_p - cfg["capital"]) / cfg["capital"] * 100, 2),
                "Final Value":      round(rem + shares * last_p, 2),
                "Total Trades":     1,
            }

            self.after(0, lambda: self._show_compare_result(curves, summaries,
                                                            df_raw, cfg["ticker"]))
        except Exception as e:
            self.after(0, lambda: messagebox.showerror("Comparison Error", str(e)))
        finally:
            self.after(0, lambda: self.cmp_btn.config(
                state="normal", text="📊  Compare Strategies"))
            self.after(0, lambda: self.status_var.set("Ablation comparison complete."))

    def _show_compare_result(self, curves, summaries, df_raw, ticker):
        win = tk.Toplevel(self)
        win.title("Full Ablation — All Indicator Combinations")
        win.configure(bg=BG_DARK)
        win.geometry("1000x720")

        tk.Label(win, text=f"📊  Indicator Ablation Study — {ticker}",
                 bg=BG_DARK, fg=ACCENT2,
                 font=("Consolas", 14, "bold")).pack(pady=(14, 4))

        # Winner (exclude Buy & Hold from winner selection)
        active = {k: v for k, v in summaries.items() if k != "Buy & Hold"}
        winner_name = max(active, key=lambda k: active[k]["Total Return (%)"])
        tk.Label(win, text=f"🏆  Best Active Strategy:  {winner_name}  "
                            f"({summaries[winner_name]['Total Return (%)']:+.2f}%)",
                 bg=BG_DARK, fg=GOLD,
                 font=("Consolas", 11, "bold")).pack(pady=(0, 8))

        # Color palette for 7 strategies
        palette = {
            "%B Only":        "#FF6B6B",   # coral red
            "SMA Only":       "#58A6FF",   # blue
            "BBW + %B":       "#3FB950",   # bright green — our main strategy
            "SMA + %B":       "#FFB3C6",   # pink
            "SMA + BBW":      "#A0522D",   # brown
            "SMA + BBW + %B": "#A371F7",   # purple
            "Buy & Hold":     "#8B949E",   # gray (dashed)
        }

        # Equity curve chart
        fig = plt.Figure(figsize=(9, 4), facecolor=BG_DARK)
        ax  = fig.add_subplot(111)
        ax.set_facecolor(BG_PANEL)
        min_len = min(len(c) for c in curves.values())
        x       = df_raw.index[-min_len:]
        for name, curve in curves.items():
            lw = 2.5 if name == "SMA + BBW + %B" else (1.0 if name == "Buy & Hold" else 1.4)
            ls = "--" if name == "Buy & Hold" else "-"
            ax.plot(x, curve[-min_len:], color=palette.get(name, TEXT_MAIN),
                    lw=lw, ls=ls, label=name)
        ax.set_xlabel("Date", color=TEXT_SUB, fontsize=9)
        ax.set_ylabel("Portfolio Value ($)", color=TEXT_SUB, fontsize=9)
        ax.set_title("Equity Curves — All Indicator Combinations vs Buy & Hold",
                     color=TEXT_MAIN, fontweight="bold")
        ax.tick_params(colors=TEXT_SUB, labelsize=8)
        ax.legend(facecolor=BG_PANEL, labelcolor=TEXT_MAIN, fontsize=7,
                  ncol=2, loc="upper left")
        for sp in ax.spines.values():
            sp.set_edgecolor(BORDER)
        ax.grid(alpha=0.15, color=BORDER)
        plt.setp(ax.get_xticklabels(), rotation=20)
        canvas = FigureCanvasTkAgg(fig, master=win)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True, padx=12, pady=4)

        # Summary table
        cols = ("Strategy", "Return (%)", "Final Value ($)", "Trades")
        tree = ttk.Treeview(win, columns=cols, show="headings",
                            height=len(summaries), style="Dark.Treeview")
        for c in cols:
            tree.heading(c, text=c)
            tree.column(c, width=200, anchor="center")

        # Sort by return descending
        sorted_names = sorted(summaries, key=lambda k: summaries[k]["Total Return (%)"],
                              reverse=True)
        for name in sorted_names:
            s   = summaries[name]
            ret = s["Total Return (%)"]
            fv  = s.get("Final Value", s.get("Final Value", 0))
            tr  = s["Total Trades"]
            tag = "winner" if name == winner_name else ("bnh" if name == "Buy & Hold" else "")
            tree.insert("", "end", values=(
                name,
                f"{ret:+.2f}%",
                f"${fv:,.0f}",
                tr,
            ), tags=(tag,))

        tree.tag_configure("winner", foreground=GOLD)
        tree.tag_configure("bnh",    foreground=TEXT_SUB)
        tree.pack(fill=tk.X, padx=12, pady=(4, 12))

    # =========================================================================
    #  BONUS #4 — MONTE CARLO SIMULATION
    # =========================================================================
    def _mc_thread(self):
        self.mc_btn.config(state="disabled", text="⏳  Simulating...")
        self.status_var.set("Running Monte Carlo simulation...")
        threading.Thread(target=self._run_mc, daemon=True).start()

    def _run_mc(self):
        try:
            cfg    = self._read_inputs()
            df_raw = (self._df_raw
                      if self._df_raw is not None
                      else StockDataLoader(cfg["ticker"], cfg["start"], cfg["end"]).fetch())
            mc     = MonteCarloSimulator(df_raw, n_simulations=200, n_days=30)
            result = mc.run()
            self.after(0, lambda: self._show_mc_result(result, cfg["ticker"]))
        except Exception as e:
            self.after(0, lambda: messagebox.showerror("Monte Carlo Error", str(e)))
        finally:
            self.after(0, lambda: self.mc_btn.config(
                state="normal", text="🎲  Monte Carlo"))
            self.after(0, lambda: self.status_var.set("Monte Carlo complete."))

    def _show_mc_result(self, r: dict, ticker: str):
        win = tk.Toplevel(self)
        win.title("Monte Carlo — GBM Price Projection")
        win.configure(bg=BG_DARK)
        win.geometry("900x660")

        tk.Label(win, text=f"🎲  Monte Carlo Simulation — {ticker}  (200 paths, 30 days)",
                 bg=BG_DARK, fg=ACCENT,
                 font=("Consolas", 13, "bold")).pack(pady=(14, 2))
        tk.Label(win,
                 text=(f"Start Price: ${r['S0']:,.2f}   |   "
                       f"μ daily: {r['mu_daily']*100:+.4f}%   |   "
                       f"σ daily: {r['sigma_daily']*100:.4f}%"),
                 bg=BG_DARK, fg=TEXT_SUB,
                 font=("Consolas", 9)).pack(pady=(0, 6))

        # ── Fan chart ──────────────────────────────────────────────────────────
        fig = plt.Figure(figsize=(8.5, 4), facecolor=BG_DARK)
        ax  = fig.add_subplot(111)
        ax.set_facecolor(BG_PANEL)

        days = np.arange(r["paths"].shape[0])

        # Draw 300 individual paths in very low alpha
        for i in range(r["paths"].shape[1]):
            ax.plot(days, r["paths"][:, i],
                    color=ACCENT, lw=0.3, alpha=0.04)

        # Confidence bands
        ax.fill_between(days, r["p5"], r["p95"],
                        color=ACCENT, alpha=0.18, label="5–95% CI")
        ax.plot(days, r["p50"], color=ACCENT2, lw=2,   label="Median (p50)")
        ax.plot(days, r["p5"],  color=RED,     lw=1.2, ls="--", label="5th pct")
        ax.plot(days, r["p95"], color=GOLD,    lw=1.2, ls="--", label="95th pct")
        ax.axhline(r["S0"], color=TEXT_SUB, lw=0.8, ls=":", alpha=0.7,
                   label=f"Start ${r['S0']:,.0f}")

        ax.set_xlabel("Trading Days Ahead", color=TEXT_SUB, fontsize=9)
        ax.set_ylabel("Simulated Price ($)",  color=TEXT_SUB, fontsize=9)
        ax.set_title(f"GBM Price Paths — {ticker}  (30-day horizon)",
                     color=TEXT_MAIN, fontweight="bold")
        ax.tick_params(colors=TEXT_SUB, labelsize=8)
        ax.legend(facecolor=BG_PANEL, labelcolor=TEXT_MAIN, fontsize=8,
                  loc="upper left")
        for sp in ax.spines.values():
            sp.set_edgecolor(BORDER)
        ax.grid(alpha=0.15, color=BORDER)
        fig.tight_layout(pad=1.5)

        canvas = FigureCanvasTkAgg(fig, master=win)
        canvas.draw()
        canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True, padx=12, pady=4)

        # ── Stats panel ────────────────────────────────────────────────────────
        stats_frame = tk.Frame(win, bg=BG_PANEL)
        stats_frame.pack(fill=tk.X, padx=12, pady=(0, 12))

        stats = [
            ("Probability of Profit",   f"{r['prob_profit']:.1f}%",        ACCENT2),
            ("Expected Final Price",     f"${r['expected']:,.2f}",          ACCENT),
            ("95% Confidence Interval",
             f"${r['ci_low']:,.2f}  —  ${r['ci_high']:,.2f}",              GOLD),
            ("Worst Case (5th pct)",    f"${r['p5'][-1]:,.2f}",            RED),
            ("Best Case (95th pct)",    f"${r['p95'][-1]:,.2f}",           ACCENT2),
        ]
        for i, (label, value, color) in enumerate(stats):
            col_frame = tk.Frame(stats_frame, bg=BG_PANEL)
            col_frame.grid(row=0, column=i, padx=16, pady=8, sticky="n")
            tk.Label(col_frame, text=label, bg=BG_PANEL, fg=TEXT_SUB,
                     font=("Consolas", 8)).pack()
            tk.Label(col_frame, text=value, bg=BG_PANEL, fg=color,
                     font=("Consolas", 11, "bold")).pack()

    # =========================================================================
    #  CHARTS & TABLES
    # =========================================================================
    def _draw_top_charts(self, ticker, df):
        close = df["Close"].squeeze()
        for ax in [self.ax_price, self.ax_bbw, self.ax_pctb]:
            ax.cla()
            ax.set_facecolor(BG_PANEL)
            ax.tick_params(colors=TEXT_SUB, labelsize=7)
            for sp in ax.spines.values():
                sp.set_edgecolor(BORDER)
        dates = df.index

        # Price + Bollinger Bands
        ax = self.ax_price
        ax.plot(dates, close, color=ACCENT, lw=1.2, label="Close")
        ax.plot(dates, df["SMA"], color="orange", lw=1, ls="--",
                label="SMA-20", alpha=0.8)
        ax.plot(dates, df["Upper_Band"], color=TEXT_SUB, lw=0.8, ls=":")
        ax.plot(dates, df["Lower_Band"], color=TEXT_SUB, lw=0.8, ls=":")
        ax.fill_between(dates, df["Upper_Band"], df["Lower_Band"],
                        alpha=0.06, color=ACCENT)
        buys  = df[df["Signal"] ==  1]
        sells = df[df["Signal"] == -1]
        ax.scatter(buys.index,  buys["Close"].squeeze(),
                   marker="^", color=ACCENT2, s=50, zorder=5)
        ax.scatter(sells.index, sells["Close"].squeeze(),
                   marker="v", color=RED,    s=50, zorder=5)
        ax.set_title(f"{ticker} — Price & Bollinger Bands",
                     color=TEXT_MAIN, fontsize=9, fontweight="bold")
        ax.set_ylabel("Price", color=TEXT_SUB, fontsize=7)
        ax.legend(fontsize=6, facecolor=BG_PANEL,
                  labelcolor=TEXT_MAIN, framealpha=0.6)
        ax.grid(alpha=0.15, color=BORDER)
        plt.setp(ax.get_xticklabels(), rotation=30)

        # BBW
        ax = self.ax_bbw
        ax.plot(dates, df["BBW"], color=PURPLE, lw=1.3, label="BBW (%)")
        ax.axhline(df["BBW"].mean(), color="orange", ls="--",
                   lw=0.9, label="Mean BBW", alpha=0.7)
        ax.fill_between(dates, df["BBW"], alpha=0.12, color=PURPLE)
        ax.set_title("Indicator 1 — Bollinger Bands Width (BBW)",
                     color=TEXT_MAIN, fontsize=9, fontweight="bold")
        ax.set_ylabel("BBW (%)", color=TEXT_SUB, fontsize=7)
        ax.legend(fontsize=6, facecolor=BG_PANEL,
                  labelcolor=TEXT_MAIN, framealpha=0.6)
        ax.grid(alpha=0.15, color=BORDER)
        plt.setp(ax.get_xticklabels(), rotation=30)

        # %B
        ax = self.ax_pctb
        ax.plot(dates, df["Pct_B"], color="#39D353", lw=1.3, label="%B")
        ax.axhline(0.95, color=RED,    ls="--", lw=0.9,
                   label="Sell (0.95)", alpha=0.8)
        ax.axhline(0.05, color=ACCENT2, ls="--", lw=0.9,
                   label="Buy (0.05)",  alpha=0.8)
        ax.axhline(0.50, color=TEXT_SUB, ls=":",  lw=0.7, alpha=0.5)
        ax.fill_between(dates, df["Pct_B"], 0.5, alpha=0.10, color="#39D353")
        ax.set_title("Indicator 2 — Bollinger Bands %B",
                     color=TEXT_MAIN, fontsize=9, fontweight="bold")
        ax.set_ylabel("%B Value", color=TEXT_SUB, fontsize=7)
        ax.legend(fontsize=6, facecolor=BG_PANEL,
                  labelcolor=TEXT_MAIN, framealpha=0.6)
        ax.grid(alpha=0.15, color=BORDER)
        plt.setp(ax.get_xticklabels(), rotation=30)

        self.fig_top.patch.set_facecolor(CHART_BG)
        self.canvas_top.draw()

    def _draw_portfolio_chart(self, ticker, final_df, analyzer):
        ax = self.ax_port
        ax.cla()
        ax.set_facecolor(BG_PANEL)
        ax.tick_params(colors=TEXT_SUB, labelsize=7)
        for sp in ax.spines.values():
            sp.set_edgecolor(BORDER)
        dates = final_df.index
        ax.plot(dates, final_df["Portfolio_Value"],
                color=ACCENT2, lw=1.5, label="Strategy")
        ax.plot(dates, analyzer.df["BnH"],
                color="orange", lw=1.2, ls="--", label="Buy & Hold")
        ax.set_title(f"{ticker} — Portfolio Value vs Buy & Hold",
                     color=TEXT_MAIN, fontsize=9, fontweight="bold")
        ax.set_ylabel("Value ($)", color=TEXT_SUB, fontsize=7)
        ax.legend(fontsize=7, facecolor=BG_PANEL,
                  labelcolor=TEXT_MAIN, framealpha=0.6)
        ax.grid(alpha=0.15, color=BORDER)
        plt.setp(ax.get_xticklabels(), rotation=30)
        self.fig_bot.patch.set_facecolor(CHART_BG)
        self.canvas_bot.draw()

    def _populate_trade_log(self, logs):
        for item in self.trade_tree.get_children():
            self.trade_tree.delete(item)
        for log in logs:
            tag = "buy" if log["Action"] == "BUY" else "sell"
            self.trade_tree.insert("", "end", values=(
                log["Date"], log["Action"],
                f"${log['Price']:,.2f}",
                log.get("Shares", "—"),
                f"${log['Cash']:,.0f}",
            ), tags=(tag,))
        self.trade_tree.tag_configure("buy",  foreground=ACCENT2)
        self.trade_tree.tag_configure("sell", foreground=RED)

    def _populate_scorecard(self, scorecard: pd.DataFrame):
        metrics_map = {
            "Total Return (%)":    "Total Return (%)",
            "Ann. Volatility (%)": "Ann. Volatility (%)",
            "Sharpe Ratio":        "Sharpe Ratio",
            "Max Drawdown (%)":    "Max Drawdown (%)",
            "Final Value ($)":     "Final Value ($)",
        }
        for label_key, col_key in metrics_map.items():
            if label_key not in self.score_labels:
                continue
            strat_lbl, bnh_lbl = self.score_labels[label_key]
            try:
                strat_val = scorecard.loc["SMA+BBW+%B Strategy", col_key]
                bnh_val   = scorecard.loc["Buy & Hold",      col_key]
                strat_lbl.config(text=str(strat_val))
                bnh_lbl.config(text=str(bnh_val))
            except Exception:
                pass


# =============================================================================
#  ENTRY POINT
# =============================================================================
if __name__ == "__main__":
    app = StockPortfolioApp()
    app.mainloop()
